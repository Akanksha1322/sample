    <?= $this->extend('admin/layout/main') ?>
    <?= $this->section('content') ?>
    <style>
        .switch {
          position: relative;
          display: inline-block;
          width: 60px;
          height: 34px;
        }
        
        .switch input {
          opacity: 0;
          width: 0;
          height: 0;
        }
        
        .slider {
          position: absolute;
          cursor: pointer;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background-color: #ccc;
          -webkit-transition: .4s;
          transition: .4s;
          border-radius: 34px;
        }
        
        .slider:before {
          position: absolute;
          content: "";
          height: 26px;
          width: 26px;
          left: 4px;
          bottom: 4px;
          background-color: white;
          -webkit-transition: .4s;
          transition: .4s;
          border-radius: 50%;
        }
        
        input:checked + .slider {
          background-color: #2196F3;
        }
        
        input:focus + .slider {
          box-shadow: 0 0 1px #2196F3;
        }
        
        input:checked + .slider:before {
          -webkit-transform: translateX(26px);
          -ms-transform: translateX(26px);
          transform: translateX(26px);
        }
    </style>   
        <div class="content">
            <div class="animated fadeIn">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <div class="row m-0">
                                    <div class="col-sm-4"><div class="float-left"><strong class="card-title">Order List</strong></div></div>
                                    <div class="col-sm-8">
                                        <div class="float-right">
                                            <button type="button" class="btn btn-primary px-4 py-2"><a href="<?= base_url('admin-order'); ?>"><span class="text-white">Back</span></a></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <table id="bootstrap-data-table" class="table table-striped table-bordered">
                                    <tbody>
                                        <?php foreach ($order as $key => $value) { ?>
                                            <tr>
                                                <td class="text-start">Username</td>
                                                <td class="text-start"><?= ($value->first_name !== null) ? $value->first_name . ' ' . $value->last_name : "NULL"; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-start">Email</td>
                                                <td class="text-start"><?= ($value->email !== null) ? $value->email : "NULL"; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-start">Phone</td>
                                                <td class="text-start"><?= ($value->phone !== null) ? $value->phone : "NULL"; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-start">Order Id</td>
                                                <td class="text-start"><?= ($value->orderid !== null) ? $value->orderid : "NULL"; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-start">Product Name</td>
                                                <td class="text-start"><?= ($value->product_name !== null) ? $value->product_name : "NULL"; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-start">Product Message</td>
                                                <td class="text-start"><?= ($value->product_message !== null) ? $value->product_message : "NULL"; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-start">Product Weight</td>
                                                <td class="text-start"><?= ($value->product_kg !== null) ? $value->product_kg : "NULL"; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-start">Product Qantity</td>
                                                <td class="text-start"><?= ($value->product_quantity !== null) ? $value->product_quantity : "NULL"; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-start">Product Price</td>
                                                <td class="text-start"><?= ($value->product_price !== null) ? $value->product_price : "NULL"; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-start">Payment Method</td>
                                                <td class="text-start"><?= ($value->paymethod !== null) ? $value->paymethod : "NULL"; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-start">Order Date</td>
                                                <td class="text-start"><?= ($value->orderdate !== null) ? $value->orderdate : "NULL"; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-start">Order Time</td>
                                                <td class="text-start"><?= ($value->ordertime !== null) ? $value->ordertime : "NULL"; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="text-start">Address</td>
                                                <td class="text-start"><?= ($value->address !== null) ? $value->address . ' , <br>' . $value->area . ' , ' . $value->street . ' , <br>' . $value->landmark . ' , <br>' . $value->city . ' , ' . $value->state . ' - ' . $value->pincode : "NULL"; ?></td>
                                            </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?= $this->endSection() ?>
